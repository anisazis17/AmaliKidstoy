<?php 
$connect=mysqli_connect("localhost:3306", "root","123456","barang") or die("failed...");
?>
